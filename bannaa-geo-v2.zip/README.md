# بنّاء AI — نواة القياس الجيوديسية v2.0

**دار الإبداع للحلول البرمجية**

حزمة تصحيح كاملة للعيوب الجيوديسية المكتشفة في ملف `bannaa-plot__2_.geojson`.
JavaScript خام — بدون تبعيات — بدون خطوة بناء — تعمل مباشرة في المتصفح.

---

## ما الذي تم إصلاحه

| العيب | الحالة القديمة | بعد الإصلاح |
|---|---|---|
| **الاتجاهات** | 10 من 10 خاطئة (انحراف يصل 160°) | مطابقة لـ pyproj بدقة 0.05° |
| **المساحة** | 1560.4 م² (خطأ +0.27%) | 1556.26 م² (خطأ < 0.0001%) |
| **عدم اليقين** | غير موجود | ±181 م² محسوب ومعروض |
| **GeoJSON** | Feature مفرد، بلا bbox | FeatureCollection + bbox + RFC 7946 |
| **قاعدة اليد اليمنى** | غير مفروضة | مفروضة تلقائياً |
| **التقاطع الذاتي** | لا يُفحص | يُكتشف ويُبلَّغ |
| **متوسط النقاط** | غير موجود | متوسط مرجّح 1/دقة² |
| **DXF / KML / CSV** | غير موجود | مدعومة (DXF مُختبر بـ ezdxf) |
| **الوحدات العراقية** | غير موجودة | دونم / أولك |

**نتيجة الاختبارات: 106 نجح / 0 فشل** — مقارنة بمرجع pyproj/PROJ.

---

## الملفات

```
src/
  geo-core.js      النواة: UTM، المساحة، Vincenty، الاتجاهات، الفحص
  geo-capture.js   GPS: متوسط مرجّح، وضع المشي، الإدخال اليدوي
  geo-export.js    GeoJSON RFC 7946 + DXF + KML + CSV
  geo-migrate.js   ترقية الملفات القديمة + تقرير الفروقات
test/
  test.js          106 اختبار انحدار
  fixtures/        ملفك الأصلي كمرجع
output/            المخرجات المصححة لملفك
demo.html          عرض حي تفاعلي
docs/AUDIT.md      التقرير الفني الكامل
```

---

## التركيب

```html
<script src="src/geo-core.js"></script>
<script src="src/geo-capture.js"></script>
<script src="src/geo-export.js"></script>
<script src="src/geo-migrate.js"></script>
```

الترتيب مهم — `geo-core.js` أولاً.

---

## الاستخدام

### 1) بناء أرض من إحداثيات

```javascript
const plot = BannaaExport.buildPlot(ring, {
  name: 'قطعة أرض',
  method: 'gps_walk',
  gps_accuracy_m: 5,
  app_version: '2.0'
});

console.log(plot.area_m2);        // 1556.26
console.log(plot.sigma);          // 181.5  ← عدم اليقين
console.log(plot.confidence.ar);  // 'منخفضة'
console.log(plot.iraqi.text);     // '15 أولك و 56 م²'

const geojson = BannaaExport.toGeoJSON(plot);
```

`buildPlot` يقوم تلقائياً بـ: التنظيف، فرض CCW، الفحص، حساب كل شيء.

### 2) التقاط GPS بمتوسط

```javascript
BannaaCapture.capturePoint({
  seconds: 30,
  onTick: t => {
    progressBar.style.width = (t.elapsed / t.total * 100) + '%';
    label.textContent = t.message;   // 'جارٍ التثبيت… 18/30 ث — الدقة ±2.1 م'
  }
}).then(p => {
  console.log(p.lat, p.lon);
  console.log(p.accuracy_m);   // الدقة النهائية بعد المتوسط
  console.log(p.quality.ar);   // 'جيدة'
  console.log(p.samples);      // عدد القراءات المستخدمة
});
```

المتوسط المرجّح يقلل الخطأ **3–5 أضعاف** مقارنة بقراءة واحدة.

### 3) وضع المشي حول الأرض

```javascript
const w = BannaaCapture.walkTracker({
  minDistance: 3,
  onPoint: (p, n) => addMarker(p, n),
  onUpdate: s => showQuality(s.quality)
});
w.start();
// ... المستخدم يمشي حول الأرض ...
const r = w.stop();
const plot = BannaaExport.buildPlot(r.ring, {
  method: r.method,
  gps_accuracy_m: r.gps_accuracy_m
});
```

### 4) إدخال يدوي من سند الطابو

```javascript
const r = BannaaCapture.fromManualSides(startLon, startLat, [
  { length_m: 23.29, azimuth_deg: 83.9 },
  { length_m: 17.33, azimuth_deg: 82.6 }
  // ...
]);

console.log(r.closure_error_m);  // خطأ الإغلاق
console.log(r.closure_ratio);    // '1:162296'
console.log(r.acceptable);       // true
```

### 5) ترقية الملفات القديمة

```javascript
const mg = BannaaMigrate.migrate(oldGeoJSON, { gps_accuracy_m: 5 });

console.log(mg.summary);
// المساحة: 1560.4 ← 1556.3 م² (فرق -4.14 م² / -0.265%)
// ⚠ تم تصحيح 10 من 10 اتجاه:
//    • ضلع 23.29 م: «جنوبي غربي» ← «شرقي» (83.9°)
//    ...

saveFile(mg.geojson);
```

يعيد الحساب من **الهندسة** ولا يثق بالخصائص القديمة إطلاقاً.

### 6) التصدير

```javascript
const f = BannaaExport.exportAll(plot);
BannaaExport.download(f.dxf, 'plot.dxf', 'application/dxf');
BannaaExport.download(f.kml, 'plot.kml', 'application/vnd.google-earth.kml+xml');
BannaaExport.download(f.csv, 'plot.csv', 'text/csv;charset=utf-8');
```

---

## الفرق الدقيق: أي دالة مساحة أستخدم؟

| الدالة | الاستخدام | الدقة |
|---|---|---|
| `areaGeodesic()` | **الافتراضي** — العرض والتخزين | < 0.0001% |
| `areaUTM()` | التصدير لـ CAD فقط | ‑0.04% (بسبب معامل k0) |

`buildPlot` يستخدم `areaGeodesic` تلقائياً ويخزّن `areaUTM` كتحقق متقاطع في
`measurement.area_algorithm_check_utm_m2`.

---

## سبب الخطأ الأصلي في الاتجاهات

الخطأ شبه المؤكد في الكود القديم:

```javascript
// ❌ خطأ — يعامل الدرجات كإحداثيات مستوية
const dx = lon2 - lon1;
const dy = lat2 - lat1;
const az = Math.atan2(dx, dy) * 180 / Math.PI;
```

مشكلتان: (1) لا يوجد تصحيح `cos(lat)` — عند خط عرض 33° الدرجة الطولية تساوي 84%
فقط من الدرجة العرضية. (2) ترتيب معاملات `atan2` معكوس.

```javascript
// ✅ صحيح
BannaaGeo.bearing(lon1, lat1, lon2, lat2);
```

---

## الاختبارات

```bash
node test/test.js
```

تغطي: المساحة، المسافات، الأزيموث، الاتجاهات، DMS، UTM ذهاباً وإياباً،
الوحدات العراقية، التقاطع الذاتي، عدم اليقين، direct/inverse،
البناء اليدوي، GeoJSON، DXF، KML، CSV، الترقية، والحالات الحدية.

---

## خارطة الطريق

- [x] إصلاح الاتجاهات
- [x] مساحة جيوديسية
- [x] عدم اليقين
- [x] متوسط النقاط
- [x] DXF / KML / CSV
- [x] ترقية الملفات القديمة
- [ ] RTK عبر NTRIP (دقة سنتمتر)
- [ ] مطابقة مساحة السند بالطابو
- [ ] Shapefile

---

© دار الإبداع للحلول البرمجية
