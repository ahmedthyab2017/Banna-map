/* ═══════════════════════════════════════════════════════════════
   بنّاء AI — geo-migrate.js
   ترقية الملفات القديمة (المحفوظة بالكود المعيب) إلى v2
   يعيد حساب المساحة والاتجاهات من الهندسة — لا يثق بالخصائص القديمة
   دار الإبداع للحلول البرمجية
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';

  var G = global.BannaaGeo    || (typeof require !== 'undefined' ? require('./geo-core.js')   : null);
  var E = global.BannaaExport || (typeof require !== 'undefined' ? require('./geo-export.js') : null);

  /* ─── استخراج الحلقة من أي شكل GeoJSON ─── */
  function extractRing(gj) {
    if (!gj) return null;
    if (gj.type === 'FeatureCollection') {
      var f = (gj.features || []).find(function (x) {
        return x.geometry && /Polygon/.test(x.geometry.type);
      });
      return f ? extractRing(f) : null;
    }
    if (gj.type === 'Feature') {
      return gj.geometry ? extractRing(gj.geometry) : null;
    }
    if (gj.type === 'Polygon')      return gj.coordinates[0];
    if (gj.type === 'MultiPolygon') return gj.coordinates[0][0];
    if (Array.isArray(gj))          return gj;
    return null;
  }

  function extractProps(gj) {
    if (!gj) return {};
    if (gj.type === 'FeatureCollection') {
      var f = (gj.features || [])[0];
      return f ? (f.properties || {}) : {};
    }
    if (gj.type === 'Feature') return gj.properties || {};
    return {};
  }

  /* ═══════════════════════════════════════════════════════════
     الترقية: إعادة حساب كل شيء من الإحداثيات
     ═══════════════════════════════════════════════════════════ */
  function migrate(oldGeoJSON, opts) {
    opts = opts || {};
    var ring = extractRing(oldGeoJSON);
    if (!ring || ring.length < 4) {
      throw new Error('لا يمكن قراءة هندسة المضلع من الملف');
    }
    var oldProps = extractProps(oldGeoJSON);

    var plot = E.buildPlot(ring, {
      name: oldProps.name || opts.name || 'قطعة أرض',
      app_version: opts.app_version || '2.0',
      method: oldProps.measurement && oldProps.measurement.method
        ? oldProps.measurement.method
        : (opts.method || 'unknown_legacy'),
      gps_accuracy_m: opts.gps_accuracy_m != null
        ? opts.gps_accuracy_m
        : (oldProps.measurement ? oldProps.measurement.gps_accuracy_m : null),
      created: oldProps.created || new Date().toISOString(),
      frontage: (oldProps.sides || []).map(function (s) { return s.frontage || null; }),
      notes: oldProps.notes || null
    });

    var gj = E.toGeoJSON(plot);

    /* ─── تقرير الفروقات ─── */
    var diff = {
      area: null,
      perimeter: null,
      directions_changed: [],
      directions_total: 0
    };

    if (typeof oldProps.area_m2 === 'number') {
      var da = plot.area_m2 - oldProps.area_m2;
      diff.area = {
        old: oldProps.area_m2,
        new: +plot.area_m2.toFixed(1),
        delta_m2: +da.toFixed(2),
        delta_pct: +(da / oldProps.area_m2 * 100).toFixed(3)
      };
    }
    if (typeof oldProps.perimeter_m === 'number') {
      var dp = plot.perimeter_m - oldProps.perimeter_m;
      diff.perimeter = {
        old: oldProps.perimeter_m,
        new: +plot.perimeter_m.toFixed(2),
        delta_m: +dp.toFixed(3)
      };
    }

    // مقارنة الاتجاهات — نطابق بالطول لأن الترتيب قد يتغير بعد فرض CCW
    (oldProps.sides || []).forEach(function (os) {
      diff.directions_total++;
      var match = plot.sides.find(function (ns) {
        return Math.abs(ns.length_m - os.length_m) < 0.15;
      });
      if (match && os.direction && match.direction !== os.direction) {
        diff.directions_changed.push({
          length_m: os.length_m,
          old: os.direction,
          new: match.direction,
          azimuth_deg: match.azimuth_deg
        });
      }
    });

    return {
      geojson: gj,
      plot: plot,
      diff: diff,
      summary: buildSummary(diff, plot)
    };
  }

  function buildSummary(diff, plot) {
    var L = [];
    if (diff.area) {
      L.push('المساحة: ' + diff.area.old + ' ← ' + diff.area.new +
             ' م² (فرق ' + (diff.area.delta_m2 > 0 ? '+' : '') + diff.area.delta_m2 +
             ' م² / ' + diff.area.delta_pct + '%)');
    }
    if (diff.perimeter) {
      L.push('المحيط: ' + diff.perimeter.old + ' ← ' + diff.perimeter.new + ' م');
    }
    if (diff.directions_changed.length) {
      L.push('⚠ تم تصحيح ' + diff.directions_changed.length + ' من ' +
             diff.directions_total + ' اتجاه:');
      diff.directions_changed.forEach(function (d) {
        L.push('   • ضلع ' + d.length_m + ' م: «' + d.old + '» ← «' + d.new +
               '» (' + d.azimuth_deg + '°)');
      });
    } else if (diff.directions_total) {
      L.push('الاتجاهات: كلها صحيحة ✓');
    }
    if (!plot.validation.valid) {
      L.push('⛔ مشاكل هندسية:');
      plot.validation.issues.forEach(function (i) { L.push('   • ' + i.ar); });
    }
    plot.validation.warnings.forEach(function (w) { L.push('   ⚠ ' + w.ar); });
    return L.join('\n');
  }

  /* ─── ترقية دفعة كاملة ─── */
  function migrateBatch(files, opts) {
    return files.map(function (f) {
      try {
        var r = migrate(typeof f.content === 'string' ? JSON.parse(f.content) : f.content, opts);
        return { name: f.name, ok: true, result: r };
      } catch (e) {
        return { name: f.name, ok: false, error: e.message };
      }
    });
  }

  var M = {
    extractRing: extractRing,
    extractProps: extractProps,
    migrate: migrate,
    migrateBatch: migrateBatch
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = M;
  global.BannaaMigrate = M;

})(typeof window !== 'undefined' ? window : globalThis);
