/* ═══════════════════════════════════════════════════════════════
   بنّاء AI — geo-core.js
   النواة الجيوديسية: الإسقاط، المساحة، الأزيموث، عدم اليقين
   دار الإبداع للحلول البرمجية
   vanilla JS — لا تبعيات — يعمل مباشرة في المتصفح
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';

  /* ─── ثوابت WGS84 ─── */
  var WGS84 = {
    a:  6378137.0,               // نصف المحور الأكبر
    f:  1 / 298.257223563,       // التفلطح
    k0: 0.9996                   // معامل القياس لـ UTM
  };
  WGS84.e2  = 2 * WGS84.f - WGS84.f * WGS84.f;
  WGS84.ep2 = WGS84.e2 / (1 - WGS84.e2);

  var D2R = Math.PI / 180;
  var R2D = 180 / Math.PI;

  /* ═══════════════════════════════════════════════════════════
     1) اختيار نطاق UTM تلقائياً
        العراق يقع في 37N و 38N و 39N
        الفلوجة/بغداد/الأنبار → 38N (EPSG:32638)
     ═══════════════════════════════════════════════════════════ */
  function utmZone(lon) {
    return Math.floor((lon + 180) / 6) + 1;
  }

  function utmEpsg(lon, lat) {
    var z = utmZone(lon);
    return (lat >= 0 ? 32600 : 32700) + z;
  }

  /* ═══════════════════════════════════════════════════════════
     2) الإسقاط من WGS84 (درجات) إلى UTM (متر)
        هذا هو المعيار الرسمي للمساحة في العراق
     ═══════════════════════════════════════════════════════════ */
  function toUTM(lon, lat, zone) {
    var a = WGS84.a, e2 = WGS84.e2, ep2 = WGS84.ep2, k0 = WGS84.k0;
    var z    = zone || utmZone(lon);
    var lon0 = ((z - 1) * 6 - 180 + 3) * D2R;

    var phi = lat * D2R;
    var lam = lon * D2R;

    var sinP = Math.sin(phi), cosP = Math.cos(phi), tanP = Math.tan(phi);

    var N = a / Math.sqrt(1 - e2 * sinP * sinP);
    var T = tanP * tanP;
    var C = ep2 * cosP * cosP;
    var A = cosP * (lam - lon0);

    var M = a * (
        (1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256) * phi
      - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 * e2 * e2 / 1024) * Math.sin(2 * phi)
      + (15 * e2 * e2 / 256 + 45 * e2 * e2 * e2 / 1024) * Math.sin(4 * phi)
      - (35 * e2 * e2 * e2 / 3072) * Math.sin(6 * phi)
    );

    var A2 = A * A, A3 = A2 * A, A4 = A3 * A, A5 = A4 * A, A6 = A5 * A;

    var E = k0 * N * (
        A
      + (1 - T + C) * A3 / 6
      + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A5 / 120
    ) + 500000.0;

    var Nn = k0 * (
        M + N * tanP * (
          A2 / 2
        + (5 - T + 9 * C + 4 * C * C) * A4 / 24
        + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A6 / 720
        )
    );
    if (lat < 0) Nn += 10000000.0;

    return { E: E, N: Nn, zone: z };
  }

  /* ─── العكس: من UTM إلى WGS84 ─── */
  function fromUTM(E, N, zone, south) {
    var a = WGS84.a, e2 = WGS84.e2, ep2 = WGS84.ep2, k0 = WGS84.k0;
    var lon0 = ((zone - 1) * 6 - 180 + 3) * D2R;
    var x = E - 500000.0;
    var y = south ? N - 10000000.0 : N;

    var e1 = (1 - Math.sqrt(1 - e2)) / (1 + Math.sqrt(1 - e2));
    var M  = y / k0;
    var mu = M / (a * (1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256));

    var phi1 = mu
      + (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * Math.sin(2 * mu)
      + (21 * e1 * e1 / 16 - 55 * Math.pow(e1, 4) / 32) * Math.sin(4 * mu)
      + (151 * e1 * e1 * e1 / 96) * Math.sin(6 * mu)
      + (1097 * Math.pow(e1, 4) / 512) * Math.sin(8 * mu);

    var sinP1 = Math.sin(phi1), cosP1 = Math.cos(phi1), tanP1 = Math.tan(phi1);
    var N1 = a / Math.sqrt(1 - e2 * sinP1 * sinP1);
    var T1 = tanP1 * tanP1;
    var C1 = ep2 * cosP1 * cosP1;
    var R1 = a * (1 - e2) / Math.pow(1 - e2 * sinP1 * sinP1, 1.5);
    var D  = x / (N1 * k0);

    var D2 = D * D, D3 = D2 * D, D4 = D3 * D, D5 = D4 * D, D6 = D5 * D;

    var lat = phi1 - (N1 * tanP1 / R1) * (
        D2 / 2
      - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * D4 / 24
      + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * D6 / 720
    );

    var lon = lon0 + (
        D
      - (1 + 2 * T1 + C1) * D3 / 6
      + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * D5 / 120
    ) / cosP1;

    return { lon: lon * R2D, lat: lat * R2D };
  }

  /* ═══════════════════════════════════════════════════════════
     3) المساحة — بالإسقاط UTM (الطريقة المعتمدة)
        دقة أفضل من 0.01% على أي أرض داخل النطاق
     ═══════════════════════════════════════════════════════════ */
  function areaUTM(ring) {
    var r = closeRing(ring);
    var z = utmZone(r[0][0]);
    var p = r.map(function (c) { var u = toUTM(c[0], c[1], z); return [u.E, u.N]; });
    var s = 0;
    for (var i = 0; i < p.length - 1; i++) {
      s += p[i][0] * p[i + 1][1] - p[i + 1][0] * p[i][1];
    }
    return Math.abs(s / 2);
  }

  /* ─── المساحة الجيوديسية (Karney) — للتحقق المتقاطع ─── */
  function areaGeodesic(ring) {
    var r = closeRing(ring);
    var total = 0;
    for (var i = 0; i < r.length - 1; i++) {
      var lon1 = r[i][0] * D2R,     lat1 = r[i][1] * D2R;
      var lon2 = r[i + 1][0] * D2R, lat2 = r[i + 1][1] * D2R;
      total += (lon2 - lon1) * (2 + Math.sin(lat1) + Math.sin(lat2));
    }
    // متوسط خط العرض لحساب نصف القطر المحلي
    var latM = r.reduce(function (s, p) { return s + p[1]; }, 0) / r.length * D2R;
    var sinL = Math.sin(latM);
    var e2   = WGS84.e2;
    var W    = 1 - e2 * sinL * sinL;

    // نصف قطر المجال المحلي (Gaussian mean radius) عند خط العرض هذا
    // R_G = sqrt(M * N)  حيث M نصف قطر الزوال و N نصف قطر العمود الأول
    var N_r = WGS84.a / Math.sqrt(W);                 // العمود الأول
    var M_r = WGS84.a * (1 - e2) / Math.pow(W, 1.5);  // الزوال
    var Rg  = Math.sqrt(M_r * N_r);

    return Math.abs(total * Rg * Rg / 2);
  }

  /* ═══════════════════════════════════════════════════════════
     4) المسافة والأزيموث — Vincenty العكسي (دقة مليمتر)
     ═══════════════════════════════════════════════════════════ */
  function inverse(lon1, lat1, lon2, lat2) {
    var a = WGS84.a, f = WGS84.f, b = a * (1 - f);
    var L = (lon2 - lon1) * D2R;
    var U1 = Math.atan((1 - f) * Math.tan(lat1 * D2R));
    var U2 = Math.atan((1 - f) * Math.tan(lat2 * D2R));
    var sU1 = Math.sin(U1), cU1 = Math.cos(U1);
    var sU2 = Math.sin(U2), cU2 = Math.cos(U2);

    var lam = L, lamP, iter = 0;
    var sLam, cLam, sSig, cSig, sig, sAlpha, cSqAlpha, c2SigM, C;

    do {
      sLam = Math.sin(lam); cLam = Math.cos(lam);
      var t1 = cU2 * sLam;
      var t2 = cU1 * sU2 - sU1 * cU2 * cLam;
      sSig = Math.sqrt(t1 * t1 + t2 * t2);
      if (sSig === 0) return { dist: 0, az1: 0, az2: 0 };
      cSig = sU1 * sU2 + cU1 * cU2 * cLam;
      sig  = Math.atan2(sSig, cSig);
      sAlpha = cU1 * cU2 * sLam / sSig;
      cSqAlpha = 1 - sAlpha * sAlpha;
      c2SigM = cSqAlpha !== 0 ? cSig - 2 * sU1 * sU2 / cSqAlpha : 0;
      C = f / 16 * cSqAlpha * (4 + f * (4 - 3 * cSqAlpha));
      lamP = lam;
      lam = L + (1 - C) * f * sAlpha *
        (sig + C * sSig * (c2SigM + C * cSig * (-1 + 2 * c2SigM * c2SigM)));
    } while (Math.abs(lam - lamP) > 1e-12 && ++iter < 200);

    var uSq = cSqAlpha * (a * a - b * b) / (b * b);
    var A = 1 + uSq / 16384 * (4096 + uSq * (-768 + uSq * (320 - 175 * uSq)));
    var B = uSq / 1024 * (256 + uSq * (-128 + uSq * (74 - 47 * uSq)));
    var dSig = B * sSig * (c2SigM + B / 4 * (
        cSig * (-1 + 2 * c2SigM * c2SigM)
      - B / 6 * c2SigM * (-3 + 4 * sSig * sSig) * (-3 + 4 * c2SigM * c2SigM)
    ));

    var dist = b * A * (sig - dSig);
    var az1 = Math.atan2(cU2 * sLam,  cU1 * sU2 - sU1 * cU2 * cLam) * R2D;
    var az2 = Math.atan2(cU1 * sLam, -sU1 * cU2 + cU1 * sU2 * cLam) * R2D;

    return {
      dist: dist,
      az1: (az1 + 360) % 360,
      az2: (az2 + 360) % 360
    };
  }

  /* ─── الأزيموث الأمامي فقط (سريع) ─── */
  function bearing(lon1, lat1, lon2, lat2) {
    var p1 = lat1 * D2R, p2 = lat2 * D2R, dl = (lon2 - lon1) * D2R;
    var y = Math.sin(dl) * Math.cos(p2);
    var x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
    return (Math.atan2(y, x) * R2D + 360) % 360;   // ⚠ atan2(y,x) — ليس (x,y)
  }

  /* ═══════════════════════════════════════════════════════════
     5) الاتجاهات العربية — 16 جهة
     ═══════════════════════════════════════════════════════════ */
  var DIRS_16 = [
    'شمالي', 'شمالي شمالي شرقي', 'شمالي شرقي', 'شرقي شمالي شرقي',
    'شرقي', 'شرقي جنوبي شرقي', 'جنوبي شرقي', 'جنوبي جنوبي شرقي',
    'جنوبي', 'جنوبي جنوبي غربي', 'جنوبي غربي', 'غربي جنوبي غربي',
    'غربي', 'غربي شمالي غربي', 'شمالي غربي', 'شمالي شمالي غربي'
  ];
  var DIRS_8 = [
    'شمالي', 'شمالي شرقي', 'شرقي', 'جنوبي شرقي',
    'جنوبي', 'جنوبي غربي', 'غربي', 'شمالي غربي'
  ];

  function azToArabic(az, sectors) {
    az = ((az % 360) + 360) % 360;
    if (sectors === 8) return DIRS_8[Math.round(az / 45) % 8];
    return DIRS_16[Math.round(az / 22.5) % 16];
  }

  function toDMS(az) {
    az = ((az % 360) + 360) % 360;
    var d = Math.floor(az);
    var mF = (az - d) * 60;
    var m = Math.floor(mF);
    var s = Math.round((mF - m) * 60);
    if (s === 60) { s = 0; m++; }
    if (m === 60) { m = 0; d++; }
    return d + '°' + pad(m) + "'" + pad(s) + '"';
  }

  /* ─── الاتجاه المساحي التقليدي: N 45°30'00" E ─── */
  function toSurveyorBearing(az) {
    az = ((az % 360) + 360) % 360;
    var ns, ew, ang;
    if (az <= 90)       { ns = 'ش'; ew = 'ق'; ang = az; }
    else if (az <= 180) { ns = 'ج'; ew = 'ق'; ang = 180 - az; }
    else if (az <= 270) { ns = 'ج'; ew = 'غ'; ang = az - 180; }
    else                { ns = 'ش'; ew = 'غ'; ang = 360 - az; }
    return ns + ' ' + toDMS(ang) + ' ' + ew;
  }

  /* ═══════════════════════════════════════════════════════════
     6) عدم اليقين في المساحة
        σ_A ≈ σ_pos × P / √(2n)
     ═══════════════════════════════════════════════════════════ */
  function areaUncertainty(perimeter_m, gpsAccuracy_m, nVertices) {
    if (!gpsAccuracy_m || !nVertices) return null;
    return (gpsAccuracy_m * perimeter_m) / Math.sqrt(2 * nVertices);
  }

  function confidenceLabel(sigma, area) {
    if (sigma == null || !area) return { key: 'unknown', ar: 'غير معروفة', color: '#94a3b8' };
    var r = sigma / area;
    if (r < 0.02) return { key: 'high',   ar: 'عالية',   color: '#16a34a' };
    if (r < 0.08) return { key: 'medium', ar: 'متوسطة',  color: '#f59e0b' };
    return          { key: 'low',    ar: 'منخفضة', color: '#dc2626' };
  }

  /* ═══════════════════════════════════════════════════════════
     7) وحدات القياس العراقية
     ═══════════════════════════════════════════════════════════ */
  var IQ_UNITS = {
    donum: 2500,     // الدونم العراقي = 2500 م²
    ulunk: 100,      // الأولك = 100 م² (1/25 دونم)
    meshara: 2500    // مشارة = دونم (مرادف محلي)
  };

  function toIraqiUnits(area_m2) {
    var d  = Math.floor(area_m2 / IQ_UNITS.donum);
    var rem = area_m2 - d * IQ_UNITS.donum;
    var u  = Math.floor(rem / IQ_UNITS.ulunk);
    var m  = rem - u * IQ_UNITS.ulunk;
    var parts = [];
    if (d) parts.push(d + ' دونم');
    if (u) parts.push(u + ' أولك');
    if (m >= 0.5) parts.push(m.toFixed(0) + ' م²');
    return {
      donum: +(area_m2 / IQ_UNITS.donum).toFixed(4),
      ulunk: +(area_m2 / IQ_UNITS.ulunk).toFixed(2),
      text:  parts.length ? parts.join(' و ') : '0 م²'
    };
  }

  /* ═══════════════════════════════════════════════════════════
     8) مساعدات الهندسة
     ═══════════════════════════════════════════════════════════ */
  function closeRing(ring) {
    var r = ring.slice();
    var f = r[0], l = r[r.length - 1];
    if (f[0] !== l[0] || f[1] !== l[1]) r.push([f[0], f[1]]);
    return r;
  }

  function openRing(ring) {
    var r = ring.slice();
    while (r.length > 1) {
      var f = r[0], l = r[r.length - 1];
      if (f[0] === l[0] && f[1] === l[1]) r.pop(); else break;
    }
    return r;
  }

  /* ─── الاتجاه الدوراني: موجب = عكس عقارب الساعة ─── */
  function signedAreaDeg(ring) {
    var r = closeRing(ring), s = 0;
    for (var i = 0; i < r.length - 1; i++) {
      s += (r[i][0] * r[i + 1][1]) - (r[i + 1][0] * r[i][1]);
    }
    return s / 2;
  }
  function isCCW(ring) { return signedAreaDeg(ring) > 0; }

  /* ─── فرض قاعدة اليد اليمنى RFC 7946: الحلقة الخارجية CCW ─── */
  function enforceRightHand(ring) {
    var r = closeRing(ring);
    return isCCW(r) ? r : r.reverse();
  }

  /* ─── صندوق الإحاطة ─── */
  function bbox(ring) {
    var lo = ring.map(function (p) { return p[0]; });
    var la = ring.map(function (p) { return p[1]; });
    return [Math.min.apply(null, lo), Math.min.apply(null, la),
            Math.max.apply(null, lo), Math.max.apply(null, la)];
  }

  /* ─── المركز (centroid) بالإسقاط ─── */
  function centroid(ring) {
    var r = closeRing(ring);
    var z = utmZone(r[0][0]);
    var p = r.map(function (c) { var u = toUTM(c[0], c[1], z); return [u.E, u.N]; });
    var cx = 0, cy = 0, A = 0;
    for (var i = 0; i < p.length - 1; i++) {
      var cr = p[i][0] * p[i + 1][1] - p[i + 1][0] * p[i][1];
      A  += cr;
      cx += (p[i][0] + p[i + 1][0]) * cr;
      cy += (p[i][1] + p[i + 1][1]) * cr;
    }
    A /= 2;
    if (A === 0) return { lon: r[0][0], lat: r[0][1] };
    cx /= (6 * A); cy /= (6 * A);
    var g = fromUTM(cx, cy, z, false);
    return { lon: g.lon, lat: g.lat, E: cx, N: cy, zone: z };
  }

  /* ─── كشف التقاطع الذاتي ─── */
  function segIntersect(p1, p2, p3, p4) {
    function o(a, b, c) {
      var v = (b[1] - a[1]) * (c[0] - b[0]) - (b[0] - a[0]) * (c[1] - b[1]);
      return v === 0 ? 0 : (v > 0 ? 1 : 2);
    }
    function onSeg(a, b, c) {
      return b[0] <= Math.max(a[0], c[0]) && b[0] >= Math.min(a[0], c[0]) &&
             b[1] <= Math.max(a[1], c[1]) && b[1] >= Math.min(a[1], c[1]);
    }
    var o1 = o(p1, p2, p3), o2 = o(p1, p2, p4);
    var o3 = o(p3, p4, p1), o4 = o(p3, p4, p2);
    if (o1 !== o2 && o3 !== o4) return true;
    if (o1 === 0 && onSeg(p1, p3, p2)) return true;
    if (o2 === 0 && onSeg(p1, p4, p2)) return true;
    if (o3 === 0 && onSeg(p3, p1, p4)) return true;
    if (o4 === 0 && onSeg(p3, p2, p4)) return true;
    return false;
  }

  function findSelfIntersections(ring) {
    var r = closeRing(ring), hits = [];
    var n = r.length - 1;
    for (var i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        if (j === i) continue;
        if (j === i + 1) continue;                    // متجاورة
        if (i === 0 && j === n - 1) continue;         // الأولى والأخيرة
        if (segIntersect(r[i], r[i + 1], r[j], r[j + 1])) {
          hits.push({ side_a: i + 1, side_b: j + 1 });
        }
      }
    }
    return hits;
  }

  /* ─── تنظيف: دمج النقاط المتقاربة جداً ─── */
  function dedupe(ring, tol_m) {
    tol_m = tol_m || 0.30;
    var r = openRing(ring), out = [r[0]];
    for (var i = 1; i < r.length; i++) {
      var d = inverse(out[out.length - 1][0], out[out.length - 1][1], r[i][0], r[i][1]).dist;
      if (d > tol_m) out.push(r[i]);
    }
    return out;
  }

  /* ─── إغلاق تلقائي: إذا آخر نقطة قريبة من الأولى ─── */
  function autoSnapClose(ring, tol_m) {
    tol_m = tol_m || 2.0;
    var r = openRing(ring);
    if (r.length < 3) return { ring: r, snapped: false, gap_m: null };
    var g = inverse(r[r.length - 1][0], r[r.length - 1][1], r[0][0], r[0][1]).dist;
    if (g <= tol_m) {
      return { ring: r, snapped: true, gap_m: +g.toFixed(2) };
    }
    return { ring: r, snapped: false, gap_m: +g.toFixed(2) };
  }

  /* ─── فحص شامل لصحة المضلع ─── */
  function validate(ring) {
    var issues = [], warns = [];
    var r = openRing(ring);

    if (r.length < 3) issues.push({ code: 'TOO_FEW', ar: 'المضلع يحتاج 3 نقاط على الأقل' });

    var xs = findSelfIntersections(r);
    if (xs.length) {
      issues.push({
        code: 'SELF_INTERSECT',
        ar: 'المضلع يتقاطع مع نفسه عند الأضلاع: ' +
            xs.map(function (h) { return h.side_a + '×' + h.side_b; }).join('، '),
        detail: xs
      });
    }

    // أضلاع قصيرة جداً
    var c = closeRing(r);
    for (var i = 0; i < c.length - 1; i++) {
      var d = inverse(c[i][0], c[i][1], c[i + 1][0], c[i + 1][1]).dist;
      if (d < 0.5) warns.push({ code: 'SHORT_SIDE', ar: 'الضلع ' + (i + 1) + ' قصير جداً (' + d.toFixed(2) + ' م)' });
    }

    // زوايا شبه مستقيمة (نقطة زائدة)
    for (var k = 0; k < c.length - 1; k++) {
      var prev = c[(k - 1 + c.length - 1) % (c.length - 1)];
      var cur  = c[k];
      var nxt  = c[k + 1];
      var a1 = bearing(prev[0], prev[1], cur[0], cur[1]);
      var a2 = bearing(cur[0], cur[1], nxt[0], nxt[1]);
      var turn = Math.abs(((a2 - a1 + 540) % 360) - 180);
      if (turn > 177) warns.push({ code: 'COLLINEAR', ar: 'النقطة ' + (k + 1) + ' شبه مستقيمة — يمكن حذفها' });
    }

    return { valid: issues.length === 0, issues: issues, warnings: warns };
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  /* ═══════════════════════════════════════════════════════════
     التصدير
     ═══════════════════════════════════════════════════════════ */
  var GeoCore = {
    WGS84: WGS84,
    IQ_UNITS: IQ_UNITS,
    utmZone: utmZone,
    utmEpsg: utmEpsg,
    toUTM: toUTM,
    fromUTM: fromUTM,
    areaUTM: areaUTM,
    areaGeodesic: areaGeodesic,
    inverse: inverse,
    bearing: bearing,
    azToArabic: azToArabic,
    toDMS: toDMS,
    toSurveyorBearing: toSurveyorBearing,
    areaUncertainty: areaUncertainty,
    confidenceLabel: confidenceLabel,
    toIraqiUnits: toIraqiUnits,
    closeRing: closeRing,
    openRing: openRing,
    isCCW: isCCW,
    enforceRightHand: enforceRightHand,
    bbox: bbox,
    centroid: centroid,
    findSelfIntersections: findSelfIntersections,
    dedupe: dedupe,
    autoSnapClose: autoSnapClose,
    validate: validate
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = GeoCore;
  global.BannaaGeo = GeoCore;

})(typeof window !== 'undefined' ? window : globalThis);
