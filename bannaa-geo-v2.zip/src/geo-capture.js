/* ═══════════════════════════════════════════════════════════════
   بنّاء AI — geo-capture.js
   التقاط نقاط GPS بمتوسط مرجّح + مراقبة الجودة
   دار الإبداع للحلول البرمجية
   يعتمد على: geo-core.js
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';

  var G = global.BannaaGeo || (typeof require !== 'undefined' ? require('./geo-core.js') : null);

  /* ─── عتبات الجودة (متر) ─── */
  var QUALITY = {
    excellent: 3,    // RTK / ظروف مثالية
    good:      6,    // هاتف في مكان مفتوح
    fair:      12,   // مقبول
    poor:      20    // فوقها: ارفض
  };

  function qualityOf(acc) {
    if (acc == null)            return { key: 'unknown',   ar: 'غير معروفة', color: '#94a3b8', ok: false };
    if (acc <= QUALITY.excellent) return { key: 'excellent', ar: 'ممتازة',    color: '#16a34a', ok: true };
    if (acc <= QUALITY.good)      return { key: 'good',      ar: 'جيدة',      color: '#65a30d', ok: true };
    if (acc <= QUALITY.fair)      return { key: 'fair',      ar: 'مقبولة',    color: '#f59e0b', ok: true };
    if (acc <= QUALITY.poor)      return { key: 'poor',      ar: 'ضعيفة',     color: '#dc2626', ok: true };
    return                             { key: 'reject',    ar: 'مرفوضة',    color: '#7f1d1d', ok: false };
  }

  /* ═══════════════════════════════════════════════════════════
     التقاط نقطة واحدة بمتوسط مرجّح
     الوزن = 1/دقة²  (القراءات الأدق تؤثر أكثر)
     ═══════════════════════════════════════════════════════════ */
  function capturePoint(opts) {
    opts = opts || {};
    var seconds   = opts.seconds   || 30;
    var maxAcc    = opts.maxAcc    || QUALITY.poor;
    var onTick    = opts.onTick    || function () {};
    var minSample = opts.minSamples || 3;

    return new Promise(function (resolve, reject) {
      if (!global.navigator || !global.navigator.geolocation) {
        return reject(new Error('خدمة الموقع غير متاحة على هذا الجهاز'));
      }

      var samples = [];
      var started = Date.now();
      var watchId = null;
      var timerId = null;
      var done    = false;

      function finish() {
        if (done) return;
        done = true;
        if (watchId !== null) global.navigator.geolocation.clearWatch(watchId);
        if (timerId !== null) clearTimeout(timerId);

        if (samples.length < minSample) {
          return reject(new Error(
            'لم نحصل على قراءات كافية (' + samples.length + '/' + minSample + '). ' +
            'قف في مكان مفتوح بعيداً عن الجدران وحاول مجدداً.'
          ));
        }

        // ─── المتوسط المرجّح بعكس مربع الدقة ───
        var sw = 0, slon = 0, slat = 0, salt = 0, swAlt = 0;
        samples.forEach(function (s) {
          var w = 1 / (s.acc * s.acc);
          sw   += w;
          slon += s.lon * w;
          slat += s.lat * w;
          if (s.alt != null) { salt += s.alt * w; swAlt += w; }
        });

        var lon = slon / sw;
        var lat = slat / sw;

        // الدقة النظرية للمتوسط
        var accTheory = Math.sqrt(1 / sw);

        // الانتشار الفعلي للقراءات (RMS عن المتوسط) — مؤشر واقعي
        var sumSq = 0;
        samples.forEach(function (s) {
          var d = G.inverse(lon, lat, s.lon, s.lat).dist;
          sumSq += d * d;
        });
        var spread = Math.sqrt(sumSq / samples.length);

        // نأخذ الأسوأ بين النظري والفعلي — تقدير محافظ وأمين
        var acc = Math.max(accTheory, spread);

        resolve({
          lon: lon,
          lat: lat,
          alt: swAlt > 0 ? salt / swAlt : null,
          accuracy_m: +acc.toFixed(2),
          accuracy_theoretical_m: +accTheory.toFixed(2),
          spread_m: +spread.toFixed(2),
          samples: samples.length,
          duration_s: +((Date.now() - started) / 1000).toFixed(1),
          best_m: +Math.min.apply(null, samples.map(function (s) { return s.acc; })).toFixed(2),
          quality: qualityOf(acc),
          method: 'gps_averaged'
        });
      }

      watchId = global.navigator.geolocation.watchPosition(
        function (pos) {
          var c = pos.coords;
          if (c.accuracy > maxAcc) {
            onTick({
              phase: 'rejected',
              samples: samples.length,
              accuracy: c.accuracy,
              elapsed: (Date.now() - started) / 1000,
              total: seconds,
              message: 'قراءة ضعيفة (±' + c.accuracy.toFixed(0) + ' م) — تم تجاهلها'
            });
            return;
          }
          samples.push({
            lon: c.longitude,
            lat: c.latitude,
            alt: c.altitude,
            acc: Math.max(c.accuracy, 0.5)   // لا نصدق دقة أقل من 50 سم من هاتف
          });
          onTick({
            phase: 'collecting',
            samples: samples.length,
            accuracy: c.accuracy,
            elapsed: (Date.now() - started) / 1000,
            total: seconds,
            message: 'جارٍ التثبيت… ' + Math.round((Date.now() - started) / 1000) + '/' + seconds + ' ث — الدقة ±' + c.accuracy.toFixed(1) + ' م'
          });
        },
        function (err) {
          if (done) return;
          done = true;
          if (watchId !== null) global.navigator.geolocation.clearWatch(watchId);
          if (timerId !== null) clearTimeout(timerId);
          var msgs = {
            1: 'تم رفض إذن الموقع. فعّله من إعدادات المتصفح.',
            2: 'تعذر تحديد الموقع. تأكد من تفعيل GPS.',
            3: 'انتهت المهلة. قف في مكان مفتوح.'
          };
          reject(new Error(msgs[err.code] || ('خطأ في الموقع: ' + err.message)));
        },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
      );

      timerId = setTimeout(finish, seconds * 1000);

      // إتاحة الإنهاء المبكر
      resolve.stop = finish;
    });
  }

  /* ═══════════════════════════════════════════════════════════
     التقاط سريع — نقطة واحدة بدون متوسط (للمعاينة فقط)
     ═══════════════════════════════════════════════════════════ */
  function quickPoint() {
    return new Promise(function (resolve, reject) {
      if (!global.navigator || !global.navigator.geolocation) {
        return reject(new Error('خدمة الموقع غير متاحة'));
      }
      global.navigator.geolocation.getCurrentPosition(
        function (p) {
          resolve({
            lon: p.coords.longitude,
            lat: p.coords.latitude,
            accuracy_m: +p.coords.accuracy.toFixed(2),
            samples: 1,
            quality: qualityOf(p.coords.accuracy),
            method: 'gps_single'
          });
        },
        function (e) { reject(new Error('تعذر تحديد الموقع: ' + e.message)); },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
      );
    });
  }

  /* ═══════════════════════════════════════════════════════════
     وضع المشي (Walk mode) — تسجيل مستمر أثناء السير حول الأرض
     يضيف نقطة كل مسافة محددة
     ═══════════════════════════════════════════════════════════ */
  function walkTracker(opts) {
    opts = opts || {};
    var minDist = opts.minDistance || 3;      // متر بين النقاط
    var maxAcc  = opts.maxAcc || QUALITY.fair;
    var onPoint = opts.onPoint || function () {};
    var onUpdate = opts.onUpdate || function () {};

    var pts = [];
    var watchId = null;
    var running = false;

    function start() {
      if (running) return;
      running = true;
      watchId = global.navigator.geolocation.watchPosition(
        function (pos) {
          var c = pos.coords;
          onUpdate({
            accuracy: c.accuracy,
            quality: qualityOf(c.accuracy),
            count: pts.length
          });
          if (c.accuracy > maxAcc) return;

          if (pts.length === 0) {
            pts.push([c.longitude, c.latitude, c.accuracy]);
            onPoint(pts[pts.length - 1], pts.length);
            return;
          }
          var last = pts[pts.length - 1];
          var d = G.inverse(last[0], last[1], c.longitude, c.latitude).dist;
          if (d >= minDist) {
            pts.push([c.longitude, c.latitude, c.accuracy]);
            onPoint(pts[pts.length - 1], pts.length);
          }
        },
        function (e) { onUpdate({ error: e.message }); },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
      );
    }

    function stop() {
      running = false;
      if (watchId !== null) global.navigator.geolocation.clearWatch(watchId);
      watchId = null;
      var ring = pts.map(function (p) { return [p[0], p[1]]; });
      var avgAcc = pts.length
        ? pts.reduce(function (s, p) { return s + p[2]; }, 0) / pts.length
        : null;
      return {
        ring: ring,
        gps_accuracy_m: avgAcc ? +avgAcc.toFixed(2) : null,
        points: pts.length,
        method: 'gps_walk'
      };
    }

    return { start: start, stop: stop, points: function () { return pts.slice(); } };
  }

  /* ═══════════════════════════════════════════════════════════
     بناء مضلع من أطوال وزوايا يدوية (سندات الطابو)
     يبدأ من نقطة معلومة ويسير بالأزيموث والمسافة
     ═══════════════════════════════════════════════════════════ */
  function fromManualSides(startLon, startLat, sides) {
    // sides: [{ length_m, azimuth_deg }, ...]
    var ring = [[startLon, startLat]];
    var lon = startLon, lat = startLat;

    sides.forEach(function (s) {
      var p = direct(lon, lat, s.azimuth_deg, s.length_m);
      lon = p.lon; lat = p.lat;
      ring.push([lon, lat]);
    });

    // خطأ الإغلاق
    var gap = G.inverse(lon, lat, startLon, startLat).dist;
    var perim = sides.reduce(function (s, x) { return s + x.length_m; }, 0);

    return {
      ring: ring,
      closure_error_m: +gap.toFixed(3),
      closure_ratio: perim > 0 ? '1:' + Math.round(perim / Math.max(gap, 0.001)) : null,
      acceptable: gap < 0.05 || (perim / Math.max(gap, 0.001)) > 5000,
      method: 'manual_sides'
    };
  }

  /* ─── المسألة الجيوديسية المباشرة (Vincenty) ─── */
  function direct(lon1, lat1, az, dist) {
    var a = G.WGS84.a, f = G.WGS84.f, b = a * (1 - f);
    var D2R = Math.PI / 180, R2D = 180 / Math.PI;
    var alpha1 = az * D2R;
    var s = dist;

    var sA1 = Math.sin(alpha1), cA1 = Math.cos(alpha1);
    var tanU1 = (1 - f) * Math.tan(lat1 * D2R);
    var cosU1 = 1 / Math.sqrt(1 + tanU1 * tanU1);
    var sinU1 = tanU1 * cosU1;

    var sigma1 = Math.atan2(tanU1, cA1);
    var sinAlpha = cosU1 * sA1;
    var cosSqAlpha = 1 - sinAlpha * sinAlpha;
    var uSq = cosSqAlpha * (a * a - b * b) / (b * b);
    var A = 1 + uSq / 16384 * (4096 + uSq * (-768 + uSq * (320 - 175 * uSq)));
    var B = uSq / 1024 * (256 + uSq * (-128 + uSq * (74 - 47 * uSq)));

    var sigma = s / (b * A), sigmaP, cos2SigmaM, sinSigma, cosSigma, dSigma, i = 0;
    do {
      cos2SigmaM = Math.cos(2 * sigma1 + sigma);
      sinSigma = Math.sin(sigma);
      cosSigma = Math.cos(sigma);
      dSigma = B * sinSigma * (cos2SigmaM + B / 4 * (
          cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM)
        - B / 6 * cos2SigmaM * (-3 + 4 * sinSigma * sinSigma) * (-3 + 4 * cos2SigmaM * cos2SigmaM)
      ));
      sigmaP = sigma;
      sigma = s / (b * A) + dSigma;
    } while (Math.abs(sigma - sigmaP) > 1e-12 && ++i < 200);

    var tmp = sinU1 * sinSigma - cosU1 * cosSigma * cA1;
    var lat2 = Math.atan2(
      sinU1 * cosSigma + cosU1 * sinSigma * cA1,
      (1 - f) * Math.sqrt(sinAlpha * sinAlpha + tmp * tmp)
    );
    var lambda = Math.atan2(sinSigma * sA1, cosU1 * cosSigma - sinU1 * sinSigma * cA1);
    var C = f / 16 * cosSqAlpha * (4 + f * (4 - 3 * cosSqAlpha));
    var L = lambda - (1 - C) * f * sinAlpha * (
        sigma + C * sinSigma * (cos2SigmaM + C * cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM))
    );

    return { lon: lon1 + L * R2D, lat: lat2 * R2D };
  }

  var Capture = {
    QUALITY: QUALITY,
    qualityOf: qualityOf,
    capturePoint: capturePoint,
    quickPoint: quickPoint,
    walkTracker: walkTracker,
    fromManualSides: fromManualSides,
    direct: direct
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Capture;
  global.BannaaCapture = Capture;

})(typeof window !== 'undefined' ? window : globalThis);
