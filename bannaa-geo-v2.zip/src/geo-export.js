/* ═══════════════════════════════════════════════════════════════
   بنّاء AI — geo-export.js
   بناء GeoJSON مطابق RFC 7946 + تصدير DXF / KML / CSV
   دار الإبداع للحلول البرمجية
   يعتمد على: geo-core.js
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';

  var G = global.BannaaGeo || (typeof require !== 'undefined' ? require('./geo-core.js') : null);

  var VENDOR = 'دار الإبداع للحلول البرمجية';
  var APP    = 'بنّاء AI';

  /* ═══════════════════════════════════════════════════════════
     بناء كائن الأرض الكامل — المصدر الوحيد للحقيقة
     ═══════════════════════════════════════════════════════════ */
  function buildPlot(ring, meta) {
    meta = meta || {};

    // 1) تنظيف + فرض قاعدة اليد اليمنى
    var clean = G.dedupe(ring, meta.dedupe_tol_m || 0.30);
    var outer = G.enforceRightHand(clean);          // مغلقة + CCW
    var open  = G.openRing(outer);

    // 2) الفحص
    var check = G.validate(open);

    // 3) القياسات — الجيوديسي هو المرجع
    var area  = G.areaGeodesic(outer);
    var areaU = G.areaUTM(outer);
    var zone  = G.utmZone(open[0][0]);
    var epsg  = G.utmEpsg(open[0][0], open[0][1]);

    // 4) الأضلاع
    var sides = [];
    var perim = 0;
    for (var i = 0; i < outer.length - 1; i++) {
      var p1 = outer[i], p2 = outer[i + 1];
      var inv = G.inverse(p1[0], p1[1], p2[0], p2[1]);
      perim += inv.dist;

      // الواجهة = عمودي على الضلع نحو الخارج
      // الحلقة CCW ⇒ الخارج = الأزيموث − 90
      var faceAz = (inv.az1 - 90 + 360) % 360;

      sides.push({
        n: i + 1,
        length_m: +inv.dist.toFixed(2),
        azimuth_deg: +inv.az1.toFixed(1),
        bearing_dms: G.toDMS(inv.az1),
        bearing_surveyor: G.toSurveyorBearing(inv.az1),
        direction: G.azToArabic(inv.az1),
        faces: G.azToArabic(faceAz),
        faces_az: +faceAz.toFixed(1),
        frontage: (meta.frontage && meta.frontage[i]) || null
      });
    }

    // 5) عدم اليقين
    var acc   = meta.gps_accuracy_m != null ? meta.gps_accuracy_m : null;
    var sigma = acc != null ? G.areaUncertainty(perim, acc, open.length) : null;
    var conf  = G.confidenceLabel(sigma, area);

    // 6) وحدات عراقية
    var iq = G.toIraqiUnits(area);
    var ctr = G.centroid(outer);
    var bb = G.bbox(outer);

    return {
      ring: outer,
      area_m2: area,
      area_utm_m2: areaU,
      perimeter_m: perim,
      sides: sides,
      sigma: sigma,
      confidence: conf,
      iraqi: iq,
      centroid: ctr,
      bbox: bb,
      zone: zone,
      epsg: epsg,
      validation: check,
      meta: meta
    };
  }

  /* ═══════════════════════════════════════════════════════════
     GeoJSON مطابق RFC 7946
     ═══════════════════════════════════════════════════════════ */
  function toGeoJSON(plot) {
    var m = plot.meta || {};
    var props = {
      name: m.name || 'قطعة أرض',
      app: APP,
      app_version: m.app_version || null,
      vendor: VENDOR,

      /* ── القياسات ── */
      area_m2: +plot.area_m2.toFixed(1),
      area_m2_uncertainty: plot.sigma != null ? +plot.sigma.toFixed(0) : null,
      area_display: plot.sigma != null
        ? Math.round(plot.area_m2) + ' ± ' + Math.round(plot.sigma) + ' م²'
        : Math.round(plot.area_m2) + ' م²',
      area_donum: plot.iraqi.donum,
      area_ulunk: plot.iraqi.ulunk,
      area_iraqi_text: plot.iraqi.text,
      perimeter_m: +plot.perimeter_m.toFixed(2),

      /* ── الجودة ── */
      measurement: {
        method: m.method || 'unknown',
        crs_source: 'EPSG:4326',
        crs_computation: 'EPSG:' + plot.epsg,
        utm_zone: plot.zone + 'N',
        area_algorithm: 'geodesic (Karney, Gaussian mean radius)',
        area_algorithm_check_utm_m2: +plot.area_utm_m2.toFixed(1),
        distance_algorithm: 'Vincenty inverse (WGS84)',
        gps_accuracy_m: m.gps_accuracy_m != null ? m.gps_accuracy_m : null,
        averaging_seconds: m.averaging_seconds || null,
        samples_per_point: m.samples_per_point || null,
        confidence: plot.confidence.ar,
        confidence_key: plot.confidence.key
      },

      /* ── الفحص ── */
      validation: {
        valid: plot.validation.valid,
        issues: plot.validation.issues,
        warnings: plot.validation.warnings
      },

      /* ── الموقع ── */
      centroid: [+plot.centroid.lon.toFixed(8), +plot.centroid.lat.toFixed(8)],
      vertices: plot.ring.length - 1,

      sides: plot.sides,

      created: m.created || new Date().toISOString(),
      notes: m.notes || null
    };

    var feature = {
      type: 'Feature',
      bbox: plot.bbox,
      properties: props,
      geometry: { type: 'Polygon', coordinates: [plot.ring] }
    };

    return {
      type: 'FeatureCollection',
      bbox: plot.bbox,
      features: [feature]
    };
  }

  /* ═══════════════════════════════════════════════════════════
     DXF — ما يطلبه كل مهندس عراقي (AutoCAD)
     إحداثيات UTM بالمتر + طبقات منفصلة + أبعاد
     ═══════════════════════════════════════════════════════════ */
  function toDXF(plot) {
    var z = plot.zone;
    var pts = plot.ring.map(function (c) {
      var u = G.toUTM(c[0], c[1], z);
      return [u.E, u.N];
    });

    // إزاحة للمركز لتفادي أرقام ضخمة في CAD
    var ox = Math.floor(pts[0][0]);
    var oy = Math.floor(pts[0][1]);
    var lp = pts.map(function (p) { return [p[0] - ox, p[1] - oy]; });

    var o = [];
    function g(code, val) { o.push(code); o.push(String(val)); }

    /* ── HEADER ── */
    g(0, 'SECTION'); g(2, 'HEADER');
    g(9, '$ACADVER');     g(1, 'AC1015');   // AutoCAD 2000 — أوسع توافق
    g(9, '$INSUNITS');    g(70, 6);         // 6 = متر
    g(9, '$MEASUREMENT'); g(70, 1);         // متري
    g(0, 'ENDSEC');

    /* ── TABLES: الطبقات ── */
    var LAYERS = [
      ['PLOT_BOUNDARY', 3], ['PLOT_POINTS', 1],
      ['PLOT_TEXT', 2],     ['PLOT_INFO', 7]
    ];

    g(0, 'SECTION'); g(2, 'TABLES');
    g(0, 'TABLE'); g(2, 'LAYER');
    g(100, 'AcDbSymbolTable');
    g(70, LAYERS.length);

    LAYERS.forEach(function (L) {
      g(0, 'LAYER');
      g(100, 'AcDbSymbolTableRecord');
      g(100, 'AcDbLayerTableRecord');
      g(2, L[0]);
      g(70, 0);
      g(62, L[1]);
      g(6, 'CONTINUOUS');
    });

    g(0, 'ENDTAB'); g(0, 'ENDSEC');

    /* ── ENTITIES ── */
    g(0, 'SECTION'); g(2, 'ENTITIES');

    /* ─── مساعد: كتابة نص ─── */
    function text(layer, x, y, h, str) {
      g(0, 'TEXT');
      g(8, layer);
      g(100, 'AcDbEntity');
      g(100, 'AcDbText');
      g(10, x.toFixed(4)); g(20, y.toFixed(4)); g(30, '0.0');
      g(40, h.toFixed(2));
      g(1, str);
    }

    // الحدود كـ LWPOLYLINE مغلق
    g(0, 'LWPOLYLINE');
    g(8, 'PLOT_BOUNDARY');
    g(100, 'AcDbEntity');
    g(100, 'AcDbPolyline');          // ← ضروري: بدونه أوتوكاد يرفض الكيان
    g(90, lp.length - 1);
    g(70, 1);                        // 1 = مغلق
    for (var i = 0; i < lp.length - 1; i++) {
      g(10, lp[i][0].toFixed(4));
      g(20, lp[i][1].toFixed(4));
    }

    // النقاط + أرقامها
    for (var j = 0; j < lp.length - 1; j++) {
      g(0, 'POINT');
      g(8, 'PLOT_POINTS');
      g(100, 'AcDbEntity');
      g(100, 'AcDbPoint');
      g(10, lp[j][0].toFixed(4)); g(20, lp[j][1].toFixed(4)); g(30, '0.0');

      text('PLOT_TEXT', lp[j][0] + 0.5, lp[j][1] + 0.5, 0.8, 'P' + (j + 1));
    }

    // نص الطول والاتجاه على منتصف كل ضلع
    for (var k = 0; k < lp.length - 1; k++) {
      var mx = (lp[k][0] + lp[k + 1][0]) / 2;
      var my = (lp[k][1] + lp[k + 1][1]) / 2;
      var s = plot.sides[k];
      // نستخدم صيغة ASCII للأزيموث لتفادي مشاكل الترميز في أوتوكاد القديم
      text('PLOT_TEXT', mx, my, 0.6,
           s.length_m.toFixed(2) + 'm  Az=' + s.azimuth_deg.toFixed(1) + 'd');
    }

    // جدول معلومات
    var info = [
      'AREA = ' + plot.area_m2.toFixed(2) + ' SQ.M',
      'AREA = ' + plot.iraqi.donum.toFixed(4) + ' DONUM',
      'PERIMETER = ' + plot.perimeter_m.toFixed(2) + ' M',
      'CRS = UTM ZONE ' + z + 'N / WGS84 (EPSG:' + plot.epsg + ')',
      'ORIGIN OFFSET E=' + ox + ' N=' + oy,
      'GENERATED BY ' + APP
    ];
    info.forEach(function (t, n) {
      text('PLOT_INFO', 0, -3 - n * 1.2, 0.7, t);
    });

    g(0, 'ENDSEC'); g(0, 'EOF');

    return o.join('\r\n') + '\r\n';
  }

  /* ═══════════════════════════════════════════════════════════
     KML — لـ Google Earth
     ═══════════════════════════════════════════════════════════ */
  function toKML(plot) {
    var m = plot.meta || {};
    var coords = plot.ring.map(function (c) {
      return c[0].toFixed(8) + ',' + c[1].toFixed(8) + ',0';
    }).join(' ');

    var rows = plot.sides.map(function (s) {
      return '<tr><td>' + s.n + '</td><td>' + s.length_m.toFixed(2) +
             '</td><td>' + s.bearing_dms + '</td><td>' + s.direction + '</td></tr>';
    }).join('');

    var desc =
      '<![CDATA[<div dir="rtl" style="font-family:Tahoma;font-size:14px">' +
      '<h3>' + esc(m.name || 'قطعة أرض') + '</h3>' +
      '<p><b>المساحة:</b> ' + plot.area_m2.toFixed(1) + ' م² (' + plot.iraqi.text + ')</p>' +
      '<p><b>المحيط:</b> ' + plot.perimeter_m.toFixed(2) + ' م</p>' +
      '<p><b>الثقة:</b> ' + plot.confidence.ar + '</p>' +
      '<table border="1" cellpadding="4" style="border-collapse:collapse">' +
      '<tr><th>الضلع</th><th>الطول (م)</th><th>الاتجاه</th><th>الجهة</th></tr>' +
      rows + '</table>' +
      '<p style="font-size:11px;color:#666">' + APP + ' — ' + VENDOR + '</p>' +
      '</div>]]>';

    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<kml xmlns="http://www.opengis.net/kml/2.2">\n' +
      '  <Document>\n' +
      '    <name>' + esc(m.name || 'قطعة أرض') + '</name>\n' +
      '    <Style id="plotStyle">\n' +
      '      <LineStyle><color>ff0080ff</color><width>3</width></LineStyle>\n' +
      '      <PolyStyle><color>4d0080ff</color></PolyStyle>\n' +
      '    </Style>\n' +
      '    <Placemark>\n' +
      '      <name>' + esc(m.name || 'قطعة أرض') + '</name>\n' +
      '      <description>' + desc + '</description>\n' +
      '      <styleUrl>#plotStyle</styleUrl>\n' +
      '      <Polygon>\n' +
      '        <tessellate>1</tessellate>\n' +
      '        <outerBoundaryIs><LinearRing><coordinates>' + coords +
      '</coordinates></LinearRing></outerBoundaryIs>\n' +
      '      </Polygon>\n' +
      '    </Placemark>\n' +
      '  </Document>\n</kml>\n';
  }

  /* ═══════════════════════════════════════════════════════════
     CSV — جدول الأضلاع + جدول النقاط بإحداثيات UTM
     ═══════════════════════════════════════════════════════════ */
  function toCSV(plot) {
    var z = plot.zone;
    var L = [];
    L.push('\ufeff');   // BOM لدعم العربية في Excel

    L.push('# ' + APP + ' — ' + VENDOR);
    L.push('# المساحة (م²),' + plot.area_m2.toFixed(2));
    L.push('# المساحة (دونم),' + plot.iraqi.donum.toFixed(4));
    L.push('# المحيط (م),' + plot.perimeter_m.toFixed(2));
    L.push('# النظام,UTM Zone ' + z + 'N / EPSG:' + plot.epsg);
    L.push('');

    L.push('النقطة,خط الطول,خط العرض,Easting,Northing');
    for (var i = 0; i < plot.ring.length - 1; i++) {
      var u = G.toUTM(plot.ring[i][0], plot.ring[i][1], z);
      L.push('P' + (i + 1) + ',' + plot.ring[i][0].toFixed(8) + ',' +
             plot.ring[i][1].toFixed(8) + ',' + u.E.toFixed(3) + ',' + u.N.toFixed(3));
    }
    L.push('');

    L.push('الضلع,الطول (م),الأزيموث,بالدرجات,الاتجاه,الواجهة,الاستخدام');
    plot.sides.forEach(function (s) {
      L.push(s.n + ',' + s.length_m.toFixed(2) + ',' + s.bearing_dms + ',' +
             s.azimuth_deg + ',' + s.direction + ',' + s.faces + ',' + (s.frontage || ''));
    });

    return L.join('\n');
  }

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* ═══════════════════════════════════════════════════════════
     تحميل ملف في المتصفح
     ═══════════════════════════════════════════════════════════ */
  function download(content, filename, mime) {
    if (typeof document === 'undefined') return;
    var blob = new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
  }

  function exportAll(plot, baseName) {
    baseName = baseName || 'bannaa-plot';
    return {
      geojson: JSON.stringify(toGeoJSON(plot), null, 2),
      dxf: toDXF(plot),
      kml: toKML(plot),
      csv: toCSV(plot)
    };
  }

  var Exp = {
    buildPlot: buildPlot,
    toGeoJSON: toGeoJSON,
    toDXF: toDXF,
    toKML: toKML,
    toCSV: toCSV,
    exportAll: exportAll,
    download: download
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Exp;
  global.BannaaExport = Exp;

})(typeof window !== 'undefined' ? window : globalThis);
