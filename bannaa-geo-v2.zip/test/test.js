/* بنّاء AI — حزمة اختبارات الانحدار
   تشغيل:  node test/test.js
   المرجع: pyproj / PROJ (WGS84) */
'use strict';
var fs = require('fs');
var path = require('path');

global.BannaaGeo = require('../src/geo-core.js');
var G = global.BannaaGeo;
var C = require('../src/geo-capture.js');
var E = require('../src/geo-export.js');
var M = require('../src/geo-migrate.js');

var pass = 0, fail = 0;
function ok(name, cond, info) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (info ? '  → ' + info : '')); }
}
function near(a, b, tol) { return Math.abs(a - b) <= tol; }
function sec(t) { console.log('\n── ' + t + ' ──'); }

/* بيانات المرجع: ملف المستخدم الحقيقي */
var PLOT = [
  [43.641726588676, 33.40336422215602],
  [43.64197603409349, 33.403386590087486],
  [43.642161106500005, 33.40340672122089],
  [43.64223889055492, 33.403435799516416],
  [43.64214769545605, 33.40353869186866],
  [43.6420296782693, 33.40362268540946],
  [43.641930436544065, 33.40370338209738],
  [43.64187947457707, 33.40376390456413],
  [43.641753410763904, 33.403734764122426],
  [43.64161393590685, 33.40369441580242],
  [43.641726588676, 33.40336422215602]
];
/* قيم pyproj المرجعية */
var REF_AREA = 1556.26;
var REF_PERIM = 162.30;
var REF_SIDES = [
  [23.34, 83.9], [17.36, 82.6], [7.92, 66.0], [14.22, 323.4], [14.40, 310.3],
  [12.86, 314.1], [8.22, 324.8], [12.16, 254.6], [13.72, 251.0], [38.09, 164.0]
];

sec('1) المساحة مقابل pyproj');
ok('areaGeodesic ضمن 0.01%', near(G.areaGeodesic(PLOT), REF_AREA, REF_AREA * 0.0001),
   G.areaGeodesic(PLOT).toFixed(3));
ok('areaUTM ضمن 0.1%', near(G.areaUTM(PLOT), REF_AREA, REF_AREA * 0.001),
   G.areaUTM(PLOT).toFixed(3));

sec('2) المسافات والأزيموث مقابل pyproj');
for (var i = 0; i < PLOT.length - 1; i++) {
  var inv = G.inverse(PLOT[i][0], PLOT[i][1], PLOT[i + 1][0], PLOT[i + 1][1]);
  ok('ضلع ' + (i + 1) + ' الطول', near(inv.dist, REF_SIDES[i][0], 0.01), inv.dist.toFixed(3));
  ok('ضلع ' + (i + 1) + ' الأزيموث', near(inv.az1, REF_SIDES[i][1], 0.05), inv.az1.toFixed(2));
}

sec('3) المحيط');
var per = 0;
for (var j = 0; j < PLOT.length - 1; j++) per += G.inverse(PLOT[j][0], PLOT[j][1], PLOT[j+1][0], PLOT[j+1][1]).dist;
ok('المحيط ضمن 5 سم', near(per, REF_PERIM, 0.05), per.toFixed(3));

sec('4) اتجاهات عربية — الخطأ الأصلي');
ok('83.9° = شرقي (كان: جنوبي غربي)', G.azToArabic(83.9) === 'شرقي', G.azToArabic(83.9));
ok('164° = جنوبي جنوبي شرقي (كان: غربي)', /جنوبي/.test(G.azToArabic(164)), G.azToArabic(164));
ok('323.4° = شمالي غربي (كان: شرقي)', G.azToArabic(323.4) === 'شمالي غربي', G.azToArabic(323.4));
ok('0° = شمالي', G.azToArabic(0) === 'شمالي');
ok('90° = شرقي', G.azToArabic(90) === 'شرقي');
ok('180° = جنوبي', G.azToArabic(180) === 'جنوبي');
ok('270° = غربي', G.azToArabic(270) === 'غربي');
ok('359.9° = شمالي (التفاف)', G.azToArabic(359.9) === 'شمالي');
ok('-90° = غربي (سالب)', G.azToArabic(-90) === 'غربي');
ok('450° = شرقي (>360)', G.azToArabic(450) === 'شرقي');
ok('8 جهات: 45° = شمالي شرقي', G.azToArabic(45, 8) === 'شمالي شرقي');

sec('5) DMS والاتجاه المساحي');
ok('DMS 83.9', G.toDMS(83.9) === "83°54'00\"", G.toDMS(83.9));
ok('DMS 0', G.toDMS(0) === "0°00'00\"", G.toDMS(0));
ok('surveyor 83.9 = ش..ق', /^ش .* ق$/.test(G.toSurveyorBearing(83.9)), G.toSurveyorBearing(83.9));
ok('surveyor 200 = ج..غ', /^ج .* غ$/.test(G.toSurveyorBearing(200)), G.toSurveyorBearing(200));
ok('surveyor 300 = ش..غ', /^ش .* غ$/.test(G.toSurveyorBearing(300)), G.toSurveyorBearing(300));

sec('6) UTM ذهاب وإياب');
var rt = 0;
[[43.64, 33.40], [45.0, 33.3], [42.5, 30.0], [47.9, 37.2]].forEach(function (p) {
  var u = G.toUTM(p[0], p[1]);
  var b = G.fromUTM(u.E, u.N, u.zone, false);
  rt = Math.max(rt, Math.abs(b.lon - p[0]), Math.abs(b.lat - p[1]));
});
ok('دقة الذهاب والإياب < 1e-8°', rt < 1e-8, rt.toExponential(2));
ok('الفلوجة نطاق 38', G.utmZone(43.64) === 38);
ok('EPSG:32638', G.utmEpsg(43.64, 33.40) === 32638);

sec('7) الوحدات العراقية');
var iq = G.toIraqiUnits(2500);
ok('2500 م² = 1 دونم', iq.donum === 1, JSON.stringify(iq));
ok('نص 2500', /1 دونم/.test(iq.text), iq.text);
ok('100 م² = 1 أولك', G.toIraqiUnits(100).ulunk === 1);
ok('1556 م² ≈ 0.62 دونم', near(G.toIraqiUnits(1556.26).donum, 0.6225, 0.001));

sec('8) الهندسة');
ok('CCW يُكتشف', G.isCCW(PLOT) === true);
var cw = PLOT.slice().reverse();
ok('CW يُكتشف', G.isCCW(cw) === false);
ok('enforceRightHand يقلب CW', G.isCCW(G.enforceRightHand(cw)) === true);
ok('enforceRightHand يبقي CCW', G.isCCW(G.enforceRightHand(PLOT)) === true);
ok('bbox صحيح', G.bbox(PLOT).length === 4 && G.bbox(PLOT)[0] < G.bbox(PLOT)[2]);
var ct = G.centroid(PLOT);
ok('المركز داخل bbox', ct.lon > G.bbox(PLOT)[0] && ct.lon < G.bbox(PLOT)[2]);
ok('المضلع الحقيقي صالح', G.validate(PLOT).valid === true);

sec('9) كشف التقاطع الذاتي');
var bowtie = [[0,0],[1,1],[1,0],[0,1],[0,0]];
ok('ربطة العنق تُكتشف', G.findSelfIntersections(bowtie).length > 0);
ok('المربع سليم', G.findSelfIntersections([[0,0],[1,0],[1,1],[0,1],[0,0]]).length === 0);
ok('validate يرفض ربطة العنق', G.validate(bowtie).valid === false);

sec('10) عدم اليقين');
var sg = G.areaUncertainty(162.3, 5, 10);
ok('σ عند دقة 5م ≈ 181 م²', near(sg, 181.5, 1), sg.toFixed(1));
ok('الثقة منخفضة عند 5م', G.confidenceLabel(sg, 1556).key === 'low');
ok('الثقة عالية عند دقة 0.05م', G.confidenceLabel(G.areaUncertainty(162.3, 0.05, 10), 1556).key === 'high');
ok('σ يقل بزيادة الدقة', G.areaUncertainty(162.3, 1, 10) < G.areaUncertainty(162.3, 5, 10));

sec('11) direct / inverse');
var werr = 0;
[0, 45, 83.9, 164, 251, 359].forEach(function (az) {
  [5, 100, 1000].forEach(function (d) {
    var p = C.direct(43.6417, 33.4033, az, d);
    var iv = G.inverse(43.6417, 33.4033, p.lon, p.lat);
    werr = Math.max(werr, Math.abs(iv.dist - d));
  });
});
ok('direct/inverse < 1mm', werr < 0.001, werr.toExponential(2));

sec('12) بناء من أضلاع يدوية (الطابو)');
var sd = [];
for (var q = 0; q < PLOT.length - 1; q++) {
  var v = G.inverse(PLOT[q][0], PLOT[q][1], PLOT[q+1][0], PLOT[q+1][1]);
  sd.push({ length_m: v.dist, azimuth_deg: v.az1 });
}
var rb = C.fromManualSides(PLOT[0][0], PLOT[0][1], sd);
ok('خطأ الإغلاق < 1 سم', rb.closure_error_m < 0.01, rb.closure_error_m);
ok('الإغلاق مقبول', rb.acceptable === true);
ok('المساحة المعاد بناؤها تطابق', near(G.areaGeodesic(rb.ring), REF_AREA, 0.1),
   G.areaGeodesic(rb.ring).toFixed(2));

sec('13) الإغلاق التلقائي والتنظيف');
var openR = PLOT.slice(0, -1);
var snap = G.autoSnapClose(openR, 50);
ok('يكتشف إمكانية الإغلاق', snap.snapped === true);
var dup = [[43.641726588676,33.40336422215602],[43.641726588676,33.40336422215602],[43.64197603409349,33.403386590087486]];
ok('dedupe يزيل المكرر', G.dedupe(dup).length === 2);

sec('14) بناء الأرض + GeoJSON');
var plot = E.buildPlot(PLOT, { name: 'قطعة اختبار', gps_accuracy_m: 5, method: 'gps_walk', app_version: '2.0' });
var gj = E.toGeoJSON(plot);
ok('نوع FeatureCollection', gj.type === 'FeatureCollection');
ok('يوجد bbox', Array.isArray(gj.bbox) && gj.bbox.length === 4);
ok('bbox داخل Feature', Array.isArray(gj.features[0].bbox));
ok('الحلقة مغلقة', String(gj.features[0].geometry.coordinates[0][0]) ===
   String(gj.features[0].geometry.coordinates[0].slice(-1)[0]));
ok('الحلقة CCW (RFC 7946)', G.isCCW(gj.features[0].geometry.coordinates[0]));
ok('10 أضلاع', gj.features[0].properties.sides.length === 10);
ok('المساحة صحيحة', near(gj.features[0].properties.area_m2, REF_AREA, 0.5));
ok('يوجد عدم يقين', gj.features[0].properties.area_m2_uncertainty > 0);
ok('نص العرض ±', /±/.test(gj.features[0].properties.area_display),
   gj.features[0].properties.area_display);
ok('CRS محسوب', gj.features[0].properties.measurement.crs_computation === 'EPSG:32638');
ok('يوجد الدونم', gj.features[0].properties.area_donum > 0);
ok('كل ضلع له azimuth_deg', gj.features[0].properties.sides.every(function (s) { return typeof s.azimuth_deg === 'number'; }));
ok('كل ضلع له bearing_dms', gj.features[0].properties.sides.every(function (s) { return /°/.test(s.bearing_dms); }));
ok('كل ضلع له faces', gj.features[0].properties.sides.every(function (s) { return !!s.faces; }));
ok('JSON قابل للتحليل', (function(){ try{ JSON.parse(JSON.stringify(gj)); return true;}catch(e){return false;} })());

sec('15) الواجهة عمودية على الضلع');
var s0 = plot.sides[0];
var perp = Math.abs(((s0.azimuth_deg - s0.faces_az + 360) % 360) - 90);
ok('الواجهة ⟂ الضلع', perp < 0.01, perp.toFixed(4));

sec('16) DXF');
var dxf = E.toDXF(plot);
ok('يبدأ بـ SECTION', dxf.indexOf('SECTION') > -1);
ok('ينتهي بـ EOF', /EOF\r\n$/.test(dxf));
ok('يحتوي LWPOLYLINE', dxf.indexOf('LWPOLYLINE') > -1);
ok('يحتوي طبقة الحدود', dxf.indexOf('PLOT_BOUNDARY') > -1);
ok('وحدات مترية ($INSUNITS=6)', dxf.indexOf('$INSUNITS') > -1);
ok('أزواج الأكواد متوازنة', dxf.trim().split(/\r\n/).length % 2 === 0);
ok('يذكر المساحة', dxf.indexOf('AREA') > -1);

sec('17) KML');
var kml = E.toKML(plot);
ok('XML صالح البداية', kml.indexOf('<?xml') === 0);
ok('يحتوي Polygon', kml.indexOf('<Polygon>') > -1);
ok('يحتوي coordinates', kml.indexOf('<coordinates>') > -1);
ok('عدد الإحداثيات صحيح', kml.match(/<coordinates>([^<]*)</)[1].trim().split(/\s+/).length === 11);

sec('18) CSV');
var csv = E.toCSV(plot);
ok('يبدأ بـ BOM', csv.charCodeAt(0) === 0xFEFF);
ok('يحتوي رؤوس النقاط', csv.indexOf('Easting') > -1);
ok('يحتوي جدول الأضلاع', csv.indexOf('الأزيموث') > -1);

sec('19) الترقية — الملف الحقيقي للمستخدم');
var oldFile = path.join(__dirname, 'fixtures', 'legacy-plot.geojson');
if (fs.existsSync(oldFile)) {
  var old = JSON.parse(fs.readFileSync(oldFile, 'utf8'));
  var mg = M.migrate(old, { gps_accuracy_m: 5 });
  ok('الترقية نجحت', !!mg.geojson);
  ok('المساحة صُححت', near(mg.geojson.features[0].properties.area_m2, REF_AREA, 0.5),
     mg.geojson.features[0].properties.area_m2);
  ok('فرق المساحة مرصود', mg.diff.area && Math.abs(mg.diff.area.delta_m2) > 3,
     mg.diff.area && mg.diff.area.delta_m2);
  ok('اتجاهات خاطئة اكتُشفت', mg.diff.directions_changed.length >= 8,
     mg.diff.directions_changed.length + '/10');
  ok('التقرير غير فارغ', mg.summary.length > 50);
  console.log('\n' + mg.summary.split('\n').map(function (l) { return '     ' + l; }).join('\n'));
} else {
  ok('ملف الاختبار موجود', false, 'fixtures/legacy-plot.geojson مفقود');
}

sec('20) حالات حدية');
ok('مضلع 3 نقاط صالح', G.validate([[0,0],[0.001,0],[0,0.001]]).valid === true);
ok('مضلع نقطتين مرفوض', G.validate([[0,0],[1,1]]).valid === false);
var tiny = [[43.64,33.40],[43.640001,33.40],[43.640001,33.400001],[43.64,33.400001]];
ok('أرض صغيرة جداً تُحسب', G.areaGeodesic(tiny) > 0);
ok('المساحة موجبة دائماً (CW)', G.areaGeodesic(cw) > 0);
ok('CW و CCW نفس المساحة', near(G.areaGeodesic(cw), G.areaGeodesic(PLOT), 0.01));

console.log('\n' + '═'.repeat(46));
console.log('  النتيجة:  ' + pass + ' نجح  |  ' + fail + ' فشل');
console.log('═'.repeat(46));
process.exit(fail ? 1 : 0);
